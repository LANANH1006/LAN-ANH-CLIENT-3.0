package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.*;

/** Toàn bộ trang cài đặt (tiếng Việt). */
public class Pages {
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }
    static Config C() { return Config.I; }

    // ---------- widget helpers ----------
    static Text onoff(String l, boolean on) { return Text.literal(l + ": " + (on ? "§aBẬT" : "§cTẮT")); }

    static Supplier<ClickableWidget> toggle(String label, BooleanSupplier g, Consumer<Boolean> s) {
        return () -> {
            ButtonWidget[] b = new ButtonWidget[1];
            b[0] = ButtonWidget.builder(onoff(label, g.getAsBoolean()), x -> { s.accept(!g.getAsBoolean()); b[0].setMessage(onoff(label, g.getAsBoolean())); Config.save(); })
                    .dimensions(0, 0, 220, 20).build();
            return b[0];
        };
    }
    static Supplier<ClickableWidget> cycle(String label, String[] names, IntSupplier g, IntConsumer s) {
        return () -> {
            ButtonWidget[] b = new ButtonWidget[1];
            b[0] = ButtonWidget.builder(Text.literal(label + ": §e" + names[g.getAsInt() % names.length]), x -> {
                s.accept((g.getAsInt() + 1) % names.length);
                b[0].setMessage(Text.literal(label + ": §e" + names[g.getAsInt() % names.length])); Config.save();
            }).dimensions(0, 0, 220, 20).build();
            return b[0];
        };
    }
    static Supplier<ClickableWidget> button(String label, Runnable r) {
        return () -> ButtonWidget.builder(Text.literal(label), x -> r.run()).dimensions(0, 0, 220, 20).build();
    }
    static Supplier<ClickableWidget> color(String label, IntSupplier g, IntConsumer s) {
        return () -> ButtonWidget.builder(Text.literal("Màu " + label + " §7(chạm để chỉnh)"),
                x -> mc().setScreen(new ColorScreen(label, mc().currentScreen, g, s))).dimensions(0, 0, 220, 20).build();
    }
    static Supplier<ClickableWidget> slider(String label, double min, double max, boolean integer, DoubleSupplier g, DoubleConsumer s) {
        return () -> new SliderWidget(0, 0, 220, 20, Text.empty(), (g.getAsDouble() - min) / (max - min)) {
            { updateMessage(); }
            double val() { return min + value * (max - min); }
            @Override protected void updateMessage() {
                double v = val(); setMessage(Text.literal(label + ": " + (integer ? String.valueOf((int) Math.round(v)) : String.format("%.1f", v))));
            }
            @Override protected void applyValue() { double v = val(); s.accept(integer ? Math.round(v) : v); }
        };
    }
    static void open(Function<Screen, Screen> f) { mc().setScreen(f.apply(mc().currentScreen)); }

    // ---------- trang ----------
    static int tab = 0;
    static final String[] TABS = {"ESP", "PvP", "Xây / Tự động", "Hiển thị", "Khác"};

    static void goTab(Screen parent, int delta) {
        tab = (tab + delta + TABS.length) % TABS.length;
        mc().setScreen(main(parent));
    }

    public static Screen main(Screen parent) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(button("◀ Hàng trước: " + TABS[(tab + TABS.length - 1) % TABS.length], () -> goTab(parent, -1)));
        m.add(button("Hàng sau: " + TABS[(tab + 1) % TABS.length] + " ▶", () -> goTab(parent, 1)));
        switch (tab) {
            case 0 -> {
                m.add(button("👁 ESP người / rương / mob", () -> open(Pages::esp)));
                m.add(button("🎯 Dây ESP (tracer)", () -> open(Pages::tracer)));
                m.add(button("⛏ ESP Block (quặng, block tùy chọn)", () -> open(Pages::blockEsp)));
                m.add(button("📡 Radar & đếm người", () -> open(Pages::radar)));
                m.add(button("🔴 Chunk đáng nghi (sus chunk)", () -> open(Pages2::sus)));
            }
            case 1 -> {
                m.add(button("🪽 Elytra Mace (+ mace liên tục)", () -> open(Pages::mace)));
                m.add(button("💎 Crystal / Pearl / Anchor", () -> open(Pages::crystal)));
                m.add(button("⚓ Combo Anchor 1 phím (J)", () -> open(Pages2::combo)));
                m.add(button("⚔ Auto PvP (V)", () -> open(Pages2::pvp)));
                m.add(button("🎯 Aimbot + vòng tròn", () -> open(Pages::aimbot)));
                m.add(button("🌀 Spin Bot (nhân vật xoay, camera đứng yên)", () -> open(Pages2::spin)));
                m.add(button("🛡 Velocity (giảm knockback)", () -> open(Pages2::vel)));
                m.add(button("🗡 Combat+: Triggerbot / Hit Select / Silent", () -> open(Pages2::combat2)));
            }
            case 2 -> {
                m.add(button("🏗 Xây theo Schematic", () -> open(Pages::printer)));
                m.add(button("⛏ Tự đào kiểu Baritone (N)", () -> open(Pages2::mine)));
                m.add(button("🛒 Auto /ah mua (KingMC)", () -> open(Pages2::ah)));
            }
            case 3 -> {
                m.add(button("💥 Shockwave nhảy / tiếp đất", () -> open(Pages2::shock)));
                m.add(button("🌈 Trail (vệt đuôi màu)", () -> open(Pages2::trail)));
                m.add(button("✨ Hiệu ứng: vòng nhảy, ripple, outline, đặt block", () -> open(Pages2::fx)));
                m.add(button("🌌 Hiệu ứng 2: splash, target, radiance, lưới, bridge", () -> open(Pages2::extra)));
                m.add(button("🎨 Chroma + giờ bầu trời", () -> open(Pages2::visual)));
                m.add(button("📊 HUD: FPS / Ping / RAM / phím", () -> open(Pages2::hud)));
                m.add(button("✏ Tâm tự vẽ (vẽ crosshair riêng)", () -> open(CrosshairScreen::new)));
                m.add(button("🚀 Giảm lag / chỉnh FPS", () -> open(Pages::lag)));
            }
            default -> {
                m.add(button("🧰 Tiện ích (chặn mở rương, macro crystal)", () -> open(Pages2::util)));
                m.add(button("🌐 Dịch chat Anh <-> Việt", () -> open(Pages2::chat)));
                m.add(button("💾 Configs (lưu / tải / chia sẻ)", () -> open(Pages2::configs)));
                m.add(button("📜 Nhật ký cập nhật (Dev log)", () -> open(Pages2::devlog)));
            }
        }
        MenuScreen s = new MenuScreen("Hàng: " + TABS[tab] + "  (" + (tab + 1) + "/" + TABS.length + ")  vuốt ngang để đổi", parent, m);
        s.swipeL = () -> goTab(parent, 1);
        s.swipeR = () -> goTab(parent, -1);
        return s;
    }

    static <E extends Enum<E>> void setEnum(net.minecraft.client.option.SimpleOption<E> opt, String name) {
        for (E e : opt.getValue().getDeclaringClass().getEnumConstants()) if (e.name().equals(name)) { opt.setValue(e); return; }
    }

    static Screen lag(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        var o = mc().options;
        m.add(button("⚡ Tối ưu FPS 1 chạm", () -> {
            setEnum(o.getParticles(), "MINIMAL");
            o.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.OFF);
            o.getEntityShadows().setValue(false);
            o.getBiomeBlendRadius().setValue(1);
            o.getGraphicsMode().setValue(net.minecraft.client.option.GraphicsMode.FAST);
            o.getEntityDistanceScaling().setValue(0.75);
            o.write(); Util.msg("Đã tối ưu FPS");
        }));
        m.add(slider("FPS tối đa (260 = không giới hạn)", 30, 260, true, () -> o.getMaxFps().getValue(), v -> o.getMaxFps().setValue((int) v)));
        m.add(slider("Tầm nhìn (chunk)", 2, 32, true, () -> o.getViewDistance().getValue(), v -> o.getViewDistance().setValue((int) v)));
        m.add(slider("Tầm mô phỏng (chunk)", 5, 32, true, () -> o.getSimulationDistance().getValue(), v -> o.getSimulationDistance().setValue((int) v)));
        m.add(slider("Khoảng cách hiện thực thể", 0.5, 5, false, () -> o.getEntityDistanceScaling().getValue(), v -> o.getEntityDistanceScaling().setValue(v)));
        m.add(slider("Làm mượt màu biome", 0, 7, true, () -> o.getBiomeBlendRadius().getValue(), v -> o.getBiomeBlendRadius().setValue((int) v)));
        m.add(toggle("Đồ họa nhanh (Fast)", () -> o.getGraphicsMode().getValue() == net.minecraft.client.option.GraphicsMode.FAST,
            v -> o.getGraphicsMode().setValue(v ? net.minecraft.client.option.GraphicsMode.FAST : net.minecraft.client.option.GraphicsMode.FANCY)));
        m.add(toggle("Hạt (particles) tối thiểu", () -> o.getParticles().getValue().name().equals("MINIMAL"),
            v -> setEnum(o.getParticles(), v ? "MINIMAL" : "ALL")));
        m.add(toggle("Tắt mây", () -> o.getCloudRenderMode().getValue() == net.minecraft.client.option.CloudRenderMode.OFF,
            v -> o.getCloudRenderMode().setValue(v ? net.minecraft.client.option.CloudRenderMode.OFF : net.minecraft.client.option.CloudRenderMode.FANCY)));
        m.add(toggle("Tắt bóng thực thể", () -> !o.getEntityShadows().getValue(), v -> o.getEntityShadows().setValue(!v)));
        m.add(toggle("VSync", () -> o.getEnableVsync().getValue(), v -> o.getEnableVsync().setValue(v)));
        return new MenuScreen("Giảm lag / FPS", p, m);
    }

    static Screen aimbot(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Aimbot (phím B)", () -> C().aimbot, v -> C().aimbot = v));
        m.add(toggle("Nhắm người chơi", () -> C().aimPlayers, v -> C().aimPlayers = v));
        m.add(toggle("Chỉ nhắm khi nhìn thấy", () -> C().aimVisibleOnly, v -> C().aimVisibleOnly = v));
        m.add(toggle("Hiện vòng tròn", () -> C().aimCircle, v -> C().aimCircle = v));
        m.add(slider("Bán kính vòng (độ)", 5, 80, true, () -> C().aimFov, v -> C().aimFov = v));
        m.add(slider("Tầm xa", 5, 100, true, () -> C().aimRange, v -> C().aimRange = v));
        m.add(slider("Độ mượt (thấp = mượt)", 5, 100, true, () -> C().aimSmooth * 100, v -> C().aimSmooth = v / 100.0));
        m.add(color("vòng aimbot", () -> C().aimColor, v -> C().aimColor = v));
        return new MenuScreen("Aimbot", p, m);
    }

    static Screen mace(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Elytra Mace (tự bay tìm & đánh)", () -> C().autoMace, v -> { if (v != C().autoMace) ElytraMace.toggle(mc()); }));
        m.add(cycle("Góc nhìn", new String[]{"Giữ nguyên", "Ngôi thứ nhất", "Ngôi 3 (sau)", "Ngôi 3 (trước)"}, () -> C().maceView, v -> C().maceView = v));
        m.add(slider("Tầm tìm đối thủ", 10, 128, true, () -> C().maceRange, v -> C().maceRange = v));
        m.add(slider("Độ cao lao xuống", 6, 40, true, () -> C().maceDiveDist, v -> C().maceDiveDist = v));
        m.add(slider("Khoảng ngang để lao", 4, 40, true, () -> C().maceHorizDive, v -> C().maceHorizDive = v));
        m.add(slider("Tự đập khi cách đối thủ (block)", 1, 4, false, () -> C().maceHitDist, v -> C().maceHitDist = v));
        m.add(slider("Cách đối thủ bao nhiêu thì đổi cánh -> áo", 6, 40, true, () -> C().maceSwapDist, v -> C().maceSwapDist = v));
        m.add(slider("Đối thủ lệch xa hơn thì bay lên lại", 4, 30, true, () -> C().maceAbortDist, v -> C().maceAbortDist = v));
        m.add(slider("Máu tối thiểu", 0, 20, true, () -> C().minSelfHealth, v -> C().minSelfHealth = v));
        m.add(toggle("Tự đổi áo <-> cánh", () -> C().maceSwapChest, v -> C().maceSwapChest = v));
        m.add(toggle("Dùng pháo hoa", () -> C().maceUseRocket, v -> C().maceUseRocket = v));
        m.add(toggle("Tự đập khi đang lao xuống (tắt = bạn tự bấm)", () -> C().maceAutoHit, v -> C().maceAutoHit = v));
        m.add(toggle("Dùng rìu phá khiên khi đối thủ chặn", () -> C().maceAxe, v -> C().maceAxe = v));
        m.add(toggle("MACE LIÊN TỤC (wind charge combo, không cần elytra)", () -> C().windMace, v -> { if (v != C().windMace) WindMace.toggle(mc()); }));
        m.add(slider("Combo: tầm tìm đối thủ", 6, 40, true, () -> C().windRange, v -> C().windRange = v));
        m.add(slider("Combo: cách bao xa thì ném wind charge", 2, 10, true, () -> C().windStartDist, v -> C().windStartDist = v));
        m.add(slider("Combo: cooldown tối thiểu để đập (%)", 20, 100, true, () -> C().windMinCd, v -> C().windMinCd = (int) v));
        m.add(toggle("Chuỗi đập: bị hất lên nhẹ -> dùng cánh lao xuống đập tiếp", () -> C().maceChain, v -> C().maceChain = v));
        m.add(slider("Chuỗi đập: đổi cánh -> áo khi cách đối thủ", 2, 10, false, () -> C().maceChainSwap, v -> C().maceChainSwap = v));
        return new MenuScreen("Elytra Mace", p, m);
    }

    static Screen crystal(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Auto Crystal (đánh 1 cái là đặt obsidian sau lưng + nổ)", () -> C().crystal, v -> C().crystal = v));
        m.add(toggle("Surround (tự đặt obsidian quanh chân)", () -> C().surround, v -> C().surround = v));
        m.add(slider("Ô hotbar chứa totem", 1, 9, true, () -> C().totemSlot, v -> C().totemSlot = (int) v));
        m.add(slider("Ô hotbar tạm (đổi đồ)", 1, 9, true, () -> C().spareSlot, v -> C().spareSlot = (int) v));
        m.add(slider("Tầm với (reach)", 3, 6, false, () -> C().reach, v -> C().reach = v));
        m.add(toggle("Tự đặt Obsidian", () -> C().crystalAutoObs, v -> C().crystalAutoObs = v));
        m.add(toggle("Crystal theo chỗ Pearl rơi", () -> C().pearlCrystal, v -> C().pearlCrystal = v));
        m.add(toggle("Pearl: phát sáng block rơi (hồng neon)", () -> C().pearlGlow, v -> C().pearlGlow = v));
        m.add(color("pearl phát sáng", () -> C().pearlGlowColor, v -> C().pearlGlowColor = v));
        m.add(slider("Tầm đặt/nổ", 3, 6, false, () -> C().crystalRange, v -> C().crystalRange = v));
        m.add(slider("Khoảng cách nổ tới đối thủ", 2, 8, false, () -> C().crystalExplodeDist, v -> C().crystalExplodeDist = v));
        m.add(slider("Sát thương tự nhận tối đa", 1, 20, true, () -> C().maxSelfDamage, v -> C().maxSelfDamage = v));
        m.add(slider("Delay (tick)", 1, 10, true, () -> C().crystalDelay, v -> C().crystalDelay = (int) v));
        m.add(toggle("Safe Anchor (1 click đặt = chắn 1 obsidian + nổ)", () -> C().anchor, v -> C().anchor = v));
        m.add(toggle("Anchor: tự đặt đúng 1 obsidian chắn", () -> C().anchorSafe, v -> C().anchorSafe = v));
        m.add(toggle("Macro Crystal (cầm crystal + giữ chuột phải vào obsidian = tự nổ)", () -> C().crystalMacro, v -> C().crystalMacro = v));
        return new MenuScreen("Crystal / Pearl / Anchor", p, m);
    }

    static Screen esp(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Hiện máu đối thủ trên đầu", () -> C().healthTag, v -> C().healthTag = v));
        m.add(toggle("Quỹ đạo pearl / đồ ném / cung", () -> C().trajOn, v -> C().trajOn = v));
        m.add(toggle("Hiện khung schematic (xanh)", () -> C().schemGhost, v -> C().schemGhost = v));
        m.add(toggle("ESP người chơi", () -> C().espPlayers, v -> C().espPlayers = v));
        m.add(toggle("ESP mob", () -> C().espMobs, v -> C().espMobs = v));
        m.add(toggle("ESP rương / ender / shulker / thùng", () -> C().espStorage, v -> C().espStorage = v));
        m.add(cycle("Kiểu hộp", new String[]{"Chỉ viền", "Chỉ khối đặc", "Viền + khối"}, () -> C().espMode, v -> C().espMode = v));
        m.add(slider("Độ đậm khối", 10, 200, true, () -> C().espAlpha, v -> C().espAlpha = (int) v));
        m.add(slider("Tầm ESP", 16, 256, true, () -> C().espRange, v -> C().espRange = v));
        m.add(color("người chơi", () -> C().espPlayerColor, v -> C().espPlayerColor = v));
        m.add(color("mob", () -> C().espMobColor, v -> C().espMobColor = v));
        m.add(color("rương", () -> C().espChestColor, v -> C().espChestColor = v));
        m.add(color("ender chest", () -> C().espEnderColor, v -> C().espEnderColor = v));
        m.add(color("shulker", () -> C().espShulkerColor, v -> C().espShulkerColor = v));
        return new MenuScreen("ESP", p, m);
    }

    static final String[] TR = {"Tắt", "1: Trên màn hình", "2: Giữa màn hình", "3: Dưới màn hình"};
    static Screen tracer(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(cycle("Dây người chơi", TR, () -> C().trPlayer, v -> C().trPlayer = v));
        m.add(cycle("Dây mob", TR, () -> C().trMob, v -> C().trMob = v));
        m.add(cycle("Dây rương", TR, () -> C().trChest, v -> C().trChest = v));
        m.add(cycle("Dây ender chest", TR, () -> C().trEnder, v -> C().trEnder = v));
        m.add(cycle("Dây shulker", TR, () -> C().trShulker, v -> C().trShulker = v));
        m.add(cycle("Dây block", TR, () -> C().trBlock, v -> C().trBlock = v));
        m.add(slider("Kéo dây lên/xuống (tất cả dây)", -80, 80, true, () -> C().tracerOffset, v -> C().tracerOffset = (int) v));
        m.add(toggle("Dùng màu riêng cho dây (theo vị trí)", () -> C().tracerOwnColor, v -> C().tracerOwnColor = v));
        m.add(color("dây loại 1 (trên)", () -> C().tracerColor1, v -> C().tracerColor1 = v));
        m.add(color("dây loại 2 (giữa)", () -> C().tracerColor2, v -> C().tracerColor2 = v));
        m.add(color("dây loại 3 (dưới)", () -> C().tracerColor3, v -> C().tracerColor3 = v));
        return new MenuScreen("Dây ESP", p, m);
    }

    static Screen blockEsp(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Bật ESP block", () -> C().espBlocks, v -> C().espBlocks = v));
        m.add(toggle("Quặng", () -> C().espBlkOres, v -> C().espBlkOres = v));
        m.add(toggle("Tiện ích (lò, bàn craft...)", () -> C().espBlkUtility, v -> C().espBlkUtility = v));
        m.add(toggle("Đặc biệt (spawner, anchor...)", () -> C().espBlkSpecial, v -> C().espBlkSpecial = v));
        m.add(slider("Tầm quét", 16, 128, true, () -> C().espBlkRange, v -> C().espBlkRange = v));
        m.add(color("quặng", () -> C().espBlkOreColor, v -> C().espBlkOreColor = v));
        m.add(color("tiện ích", () -> C().espBlkUtilityColor, v -> C().espBlkUtilityColor = v));
        m.add(color("đặc biệt", () -> C().espBlkSpecialColor, v -> C().espBlkSpecialColor = v));
        m.add(color("block tùy chỉnh", () -> C().espBlkCustomColor, v -> C().espBlkCustomColor = v));
        m.add(slider("Độ đậm màu block ESP", 5, 255, true, () -> C().espBlkAlpha, v -> C().espBlkAlpha = (int) v));
        m.add(button("🔍 Tìm block (gõ \"log\" -> hiện hết, có hình 2D)", () -> open(p2 -> new PickScreen(p2, "Tìm block - chạm để thêm / xóa", false, C().espBlkCustom, null))));
        m.add(button("📋 Danh sách block tùy chỉnh", () -> open(Pages::customBlocks)));
        return new MenuScreen("ESP Block", p, m);
    }

    static Screen customBlocks(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(button("🔍 Thêm block (gõ tên -> hiện hết, có hình)", () -> open(p2 -> new PickScreen(p2, "Tìm block - chạm để thêm / xóa", false, C().espBlkCustom, null))));
        for (String id : new ArrayList<>(C().espBlkCustom))
            m.add(button("❌ Xóa: " + id, () -> { C().espBlkCustom.remove(id); Config.save(); mc().setScreen(customBlocks(p)); }));
        return new MenuScreen("Block tùy chỉnh", p, m);
    }

    static Screen radar(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Radar", () -> C().radarOn, v -> C().radarOn = v));
        m.add(toggle("Radar: hiện đầu người chơi", () -> C().radarPlayers, v -> C().radarPlayers = v));
        m.add(toggle("Radar: hiện block ESP", () -> C().radarBlocks, v -> C().radarBlocks = v));
        m.add(slider("Kích thước radar", 50, 200, true, () -> C().radarSize, v -> C().radarSize = (int) v));
        m.add(slider("Tầm radar (block)", 16, 128, true, () -> C().radarRange, v -> C().radarRange = v));
        m.add(slider("Vị trí radar ngang (%)", 0, 100, true, () -> C().radarX, v -> C().radarX = (int) v));
        m.add(slider("Vị trí radar dọc (%)", 0, 100, true, () -> C().radarY, v -> C().radarY = (int) v));
        m.add(toggle("Hiện số người chơi", () -> C().counterOn, v -> C().counterOn = v));
        m.add(slider("Vị trí số người ngang (%)", 0, 100, true, () -> C().counterX, v -> C().counterX = (int) v));
        m.add(slider("Vị trí số người dọc (%)", 0, 100, true, () -> C().counterY, v -> C().counterY = (int) v));
        return new MenuScreen("Radar & đếm người", p, m);
    }

    static Screen printer(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Bật Printer (tự xây)", () -> C().printerOn, v -> C().printerOn = v));
        m.add(button("Đã nạp: " + (Printer.loadedName == null ? "(chưa có)" : Printer.loadedName) + " - chạm để chọn file",
                () -> open(Pages::schemList)));
        m.add(button("Đặt gốc xây tại chỗ đang đứng", () -> { Printer.setOriginHere(); Util.msg("Đã đặt gốc schematic tại vị trí của bạn"); }));
        m.add(slider("Delay (tick giữa các lần đặt)", 1, 20, true, () -> C().printerDelay, v -> C().printerDelay = (int) v));
        m.add(slider("Số block mỗi lần", 1, 10, true, () -> C().printerPerTick, v -> C().printerPerTick = (int) v));
        m.add(slider("Tầm đặt", 3, 6, false, () -> C().printerRange, v -> C().printerRange = v));
        m.add(toggle("Tự chỉnh hướng block (xoay đúng hướng)", () -> C().printerFixRotate, v -> C().printerFixRotate = v));
        m.add(toggle("Tự chỉnh note/repeater/comparator", () -> C().printerClicks, v -> C().printerClicks = v));
        m.add(cycle("Xây theo hàng", new String[]{"Tắt", "Từ dưới lên", "Từ trên xuống"}, () -> C().printerLayerMode, v -> C().printerLayerMode = v));
        m.add(toggle("Chỉ đặt block theo hướng đang nhìn", () -> C().printerLook, v -> C().printerLook = v));
        m.add(toggle("Tự đi tới chỗ cần xây", () -> C().printerWalk, v -> C().printerWalk = v));
        m.add(toggle("Giữ shift khi đặt (tránh mở rương/bàn)", () -> C().printerSneak, v -> C().printerSneak = v));
        return new MenuScreen("Xây theo Schematic", p, m);
    }

    static Screen schemList(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        List<String> files = Printer.list();
        if (files.isEmpty()) m.add(button("Chưa có file .litematic trong thư mục /schematics", () -> {}));
        for (String f : files)
            m.add(button(f, () -> {
                try { Printer.load(f); Util.msg("Đã nạp " + f + " (" + Printer.blocks.size() + " block)"); }
                catch (Exception e) { Util.msg("§cLỗi nạp schematic: " + e.getMessage()); }
                mc().setScreen(printer(((MenuScreen) p).parent));
            }));
        return new MenuScreen("Chọn schematic (.minecraft/schematics)", p, m);
    }
}

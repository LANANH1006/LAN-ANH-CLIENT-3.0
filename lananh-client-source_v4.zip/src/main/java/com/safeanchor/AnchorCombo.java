package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Bấm 1 phím: đặt anchor -> nạp glowstone -> đặt obsidian chắn trước mình -> kích nổ. Mỗi thứ đúng 1 cái. */
public class AnchorCombo {
    static int stage, cd, timeout;
    static BlockPos A;

    public static void start(MinecraftClient mc) {
        if (stage != 0 || mc.player == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult h) || h.getType() != HitResult.Type.BLOCK) { Util.warn("Nhìn vào 1 block để đặt anchor"); return; }
        if (!Util.has(s -> s.isOf(Items.RESPAWN_ANCHOR)) || !Util.has(s -> s.isOf(Items.GLOWSTONE))) { Util.warn("Thiếu Respawn Anchor hoặc Glowstone"); return; }
        A = h.getBlockPos().offset(h.getSide());
        stage = 1; cd = 0; timeout = 0;
    }

    static void next(int s) { stage = s; cd = Math.max(0, Config.I.comboDelay); timeout = 0; }

    public static void tick(MinecraftClient mc) {
        if (stage == 0) return;
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) { stage = 0; return; }
        if (cd > 0) { cd--; return; }
        if (++timeout > 40) { stage = 0; Util.warn("Combo anchor: quá thời gian, đã hủy"); return; }
        switch (stage) {
            case 1 -> { if (Util.placeBlock(A, Items.RESPAWN_ANCHOR)) next(2); }
            case 2 -> { if (Util.selectItem(s -> s.isOf(Items.GLOWSTONE)) && Util.useOnBlock(A, Direction.UP)) next(Config.I.comboObs ? 3 : 4); }
            case 3 -> {
                BlockPos pp = p.getBlockPos();
                int dx = pp.getX() - A.getX(), dz = pp.getZ() - A.getZ();
                Direction d = Math.abs(dx) >= Math.abs(dz) ? (dx > 0 ? Direction.EAST : Direction.WEST) : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
                BlockPos o = A.offset(d);
                if (o.equals(pp) || o.equals(pp.up()) || timeout > 10) { next(4); return; }
                if (!mc.world.getBlockState(o).isReplaceable() || Util.placeBlock(o, Items.OBSIDIAN)) next(4);
            }
            case 4 -> {
                Util.selectItem(s -> !s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR));
                Util.useOnBlock(A, Direction.UP);
                stage = 0;
            }
            default -> stage = 0;
        }
    }
}

package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;

public class Hud {
    public static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = Config.I;
        if (!c.enabled || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        int W = ctx.getScaledWindowWidth(), H = ctx.getScaledWindowHeight();

        if (c.showTitle) Util.title(ctx, 4, 4, 1.6f);

        if (c.counterOn) {
            String s = "Người chơi: " + Esp.countPlayers(mc);
            int w = mc.textRenderer.getWidth(s);
            int x = (int) ((W - w - 4) * c.counterX / 100.0) + 2, y = (int) ((H - 12) * c.counterY / 100.0) + 2;
            ctx.fill(x - 2, y - 2, x + w + 2, y + 10, 0x90000000);
            ctx.drawText(mc.textRenderer, s, x, y, 0xFFFF69B4, true);
        }
        if (c.radarOn) radar(ctx, mc, c, W, H);
        if (c.healthTag) healthTags(ctx, mc, c, W, H, tc.getTickDelta(false));
        if (c.aimbot && c.aimCircle) {
            double vfov = Math.max(30, mc.options.getFov().getValue());
            double r = (H / 2.0) * Math.tan(Math.toRadians(Math.min(80, c.aimFov))) / Math.tan(Math.toRadians(vfov / 2.0));
            int cx = W / 2, cy = H / 2, col = 0xFF000000 | c.aimColor;
            for (int i = 0; i < 90; i++) {
                double a = i * Math.PI * 2 / 90;
                int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
                ctx.fill(x, y, x + 2, y + 2, col);
            }
        }
    }

    static void healthTags(DrawContext ctx, MinecraftClient mc, Config c, int W, int H, float td) {
        var cam = mc.gameRenderer.getCamera();
        net.minecraft.util.math.Vec3d cp = cam.getPos();
        net.minecraft.util.math.Vec3d f = net.minecraft.util.math.Vec3d.fromPolar(cam.getPitch(), cam.getYaw());
        net.minecraft.util.math.Vec3d right = net.minecraft.util.math.Vec3d.fromPolar(0, cam.getYaw() + 90f);
        net.minecraft.util.math.Vec3d up = net.minecraft.util.math.Vec3d.fromPolar(cam.getPitch() - 90f, cam.getYaw());
        double tanV = Math.tan(Math.toRadians(Math.max(30, mc.options.getFov().getValue()) / 2.0));
        double aspect = (double) W / H;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || o.isSpectator() || o.squaredDistanceTo(mc.player) > c.espRange * c.espRange) continue;
            net.minecraft.util.math.Vec3d v = o.getLerpedPos(td).add(0, o.getHeight() + 0.5, 0).subtract(cp);
            double z = v.dotProduct(f);
            if (z <= 0.1) continue;
            double sx = W / 2.0 * (1 + v.dotProduct(right) / z / (tanV * aspect));
            double sy = H / 2.0 * (1 - v.dotProduct(up) / z / tanV);
            float hp = o.getHealth() + o.getAbsorptionAmount();
            String s = String.format("%.1f ♥", hp);
            int col = hp > 14 ? 0xFF55FF55 : hp > 7 ? 0xFFFFFF55 : 0xFFFF5555;
            int w = mc.textRenderer.getWidth(s);
            ctx.fill((int) sx - w / 2 - 2, (int) sy - 2, (int) sx + w / 2 + 2, (int) sy + 10, 0x90000000);
            ctx.drawText(mc.textRenderer, s, (int) sx - w / 2, (int) sy, col, true);
        }
    }

    static void radar(DrawContext ctx, MinecraftClient mc, Config c, int W, int H) {
        int S = Math.max(40, c.radarSize);
        int x0 = (int) ((W - S) * c.radarX / 100.0), y0 = (int) ((H - S) * c.radarY / 100.0);
        int cx = x0 + S / 2, cy = y0 + S / 2;
        ctx.fill(x0, y0, x0 + S, y0 + S, 0x80000000);
        ctx.fill(x0, y0, x0 + S, y0 + 1, 0xFFFF69B4); ctx.fill(x0, y0 + S - 1, x0 + S, y0 + S, 0xFFFF69B4);
        ctx.fill(x0, y0, x0 + 1, y0 + S, 0xFFFF69B4); ctx.fill(x0 + S - 1, y0, x0 + S, y0 + S, 0xFFFF69B4);
        ctx.fill(cx, y0 + 1, cx + 1, y0 + S - 1, 0x40FFFFFF); ctx.fill(x0 + 1, cy, x0 + S - 1, cy + 1, 0x40FFFFFF);

        double yaw = Math.toRadians(mc.player.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double scale = (S / 2.0 - 5) / c.radarRange;

        if (c.radarBlocks) {
            int n = 0;
            for (BlockEsp.Hit h : BlockEsp.hits()) {
                double dx = h.pos().getX() + 0.5 - mc.player.getX(), dz = h.pos().getZ() + 0.5 - mc.player.getZ();
                double sx = (dx * rx + dz * rz) * scale, sy = -(dx * fx + dz * fz) * scale;
                if (Math.abs(sx) > S / 2.0 - 3 || Math.abs(sy) > S / 2.0 - 3) continue;
                ctx.fill(cx + (int) sx - 1, cy + (int) sy - 1, cx + (int) sx + 2, cy + (int) sy + 2, 0xFF000000 | h.color());
                if (++n > 300) break;
            }
        }
        if (c.radarPlayers) {
            for (PlayerEntity o : mc.world.getPlayers()) {
                if (o == mc.player || o.isSpectator()) continue;
                double dx = o.getX() - mc.player.getX(), dz = o.getZ() - mc.player.getZ();
                double sx = (dx * rx + dz * rz) * scale, sy = -(dx * fx + dz * fz) * scale;
                double lim = S / 2.0 - 5;
                sx = Math.max(-lim, Math.min(lim, sx)); sy = Math.max(-lim, Math.min(lim, sy));
                if (o instanceof net.minecraft.client.network.AbstractClientPlayerEntity ap)
                    PlayerSkinDrawer.draw(ctx, ap.getSkinTextures(), cx + (int) sx - 4, cy + (int) sy - 4, 8);
            }
        }
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFF00FF00);
    }
}
